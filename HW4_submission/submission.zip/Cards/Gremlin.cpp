//
// Created by Omer Meushar on 16/01/2023.
//

#include "Gremlin.h"

void Gremlin::applyMonsterEffect(const std::unique_ptr<Player>& curPlayer) const {}

Gremlin::Gremlin() : Battle("Gremlin", FORCE, LOOT, PLAYER_HP_DAMAGE) {}


